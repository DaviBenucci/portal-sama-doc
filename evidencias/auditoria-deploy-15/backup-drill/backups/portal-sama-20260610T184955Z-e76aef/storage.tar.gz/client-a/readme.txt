Portal Sama backup drill storage fixture
